# 可运行配套示例

这里有29个独立教学程序，覆盖工具参数验证、重试、记忆、检索与评测，以及LangGraph的状态、分支、循环、Send、Command、上下文、检查点、中断、流式和函数式API。

这些程序用于补充课程。它们不是飞书或腾讯文档原片段的逐行修复，也不会让原片段自动获得“运行通过”的状态。原文、失败记录、学习进度和答题记录均不由本目录改写。

## 运行

在 `learning-site` 目录下使用现有项目环境。Windows示例：

```powershell
& projects\.venv\Scripts\python.exe -I -B -X utf8 projects\source-companions\run.py --case graph-loop
& projects\.venv\Scripts\python.exe -I -B -X utf8 projects\source-companions\run.py --all
```

如果下载后单独使用，在解压目录创建Python 3.12环境，安装同包锁定依赖，再运行：

```powershell
python -m venv .venv
& .venv\Scripts\python.exe -m pip install -r requirements-lock.txt
& .venv\Scripts\python.exe -I -B -X utf8 run.py --case graph-loop
& .venv\Scripts\python.exe -I -B -X utf8 run.py --all
```

安装依赖需要联网。示例运行不会安装依赖、读取 `.env` 或调用模型；没有本地数据库文件，SQL示例只用内存库。已核验环境为Python 3.12.14、LangGraph 1.2.17、langchain-core 1.7.0，完整版本见锁定文件。

`--case` 后只能填写已登记的示例ID。网站的“运行示例”按钮也使用同一固定程序，不接受用户代码、路径或自定义参数。

## 查看结果

`run.py` 返回JSON：`items[].status` 是本次状态，`checks` 列出已通过断言，`result` 是合成输入对应的输出。所有断言通过时退出码为0，有失败时为1。`test-results.json` 是生成网站时的核验快照，不代替本机本次运行。

`examples.py` 保存程序，`checks.py` 保存独立的预期结果，`run.py` 负责执行和边界限制。网页提供的单例源码可复制后直接运行；复制版显示输出，固定套件运行才会同时执行 `checks.py` 的断言。

## 学习边界

- `graph-loop` 用公开StateGraph API和条件边替代旧文的ChannelWriteEntry导入。输入一个a得到16个a；输入4个b得到16个b。它验证循环出口，不声称修复了原Pregel片段。
- LangGraph检查点只保存在内存，关闭进程后不保留；生产持久化需要另行选型。
- Agent与多Agent采用明确的规则角色；模型消息和流式工具参数采用合成片段，没有真实模型推理。
- 向量检索使用手写二维向量；RAG使用固定资料与关键词，不代表语义检索或生成质量。
- 规划示例是有上限的广度优先搜索，不是MCTS或ToT算法的复现。
- 提示边界示例只演示消息与资料的结构分离，不能证明已防住提示注入。
- 运行器通过Python进程审计阻止网络、子进程和文件写入，并拒绝持久数据库。这些是进程内限制，不是操作系统沙箱；不要将它改成任意代码执行器。

## 对应课程

网站的 `src/data/source-companions.json` 按原片段稳定ID和哈希保存对应关系。主题对应不表示原例已恢复；未找到足够相关的配套时，仍明确显示需要原工程或服务上下文。
