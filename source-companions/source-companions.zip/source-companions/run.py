"""Run trusted supplemental examples in an offline, write-blocked process.

python projects/source-companions/run.py --case graph-loop
python projects/source-companions/run.py --all

The report distinguishes these programs from unchanged original fragments.
Process audit is defense in depth and is not an operating-system sandbox.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
from pathlib import Path
import sys


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


examples = load_module("source_companion_examples", "examples.py")
validators = load_module("source_companion_checks", "checks.py")


class OfflineBoundary(Exception):
    pass


def install_guard():
    allowed_roots = [Path(sys.prefix).resolve(), Path(sys.base_prefix).resolve()]
    def audit(event, args):
        if event.startswith(("socket.", "subprocess.", "ctypes.")) or event in {"os.system", "os.exec", "os.posix_spawn", "os.spawn", "os.startfile", "os.remove", "os.rename", "os.rmdir", "os.mkdir", "os.chmod", "os.truncate"}:
            raise OfflineBoundary("external-effect")
        if event == "sqlite3.connect" and args[0] != ":memory:":
            raise OfflineBoundary("persistent-database")
        if event == "open":
            target, mode, flags = args
            if not isinstance(target, (str, bytes, os.PathLike)):
                raise OfflineBoundary("file-descriptor")
            candidate = Path(os.fsdecode(target)).resolve()
            if candidate.name.lower() == ".env" or candidate.name.lower().startswith(".env."):
                raise OfflineBoundary("credential-file")
            if isinstance(mode, str) and any(char in mode for char in "wax+"):
                raise OfflineBoundary("file-write")
            if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
                raise OfflineBoundary("file-write")
            if not any(candidate.is_relative_to(root) for root in allowed_roots):
                raise OfflineBoundary("outside-dependency-read")
    sys.addaudithook(audit)


def main():
    parser = argparse.ArgumentParser(description="离线配套示例；不改写或冒充原文运行结果。")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--case", choices=sorted(examples.CASES))
    group.add_argument("--all", action="store_true")
    args = parser.parse_args()
    selected = sorted(examples.CASES) if args.all else [args.case]
    hashes = {name: hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in ("examples.py", "checks.py", "run.py")}
    versions = {name: importlib.metadata.version(name) for name in ("langgraph", "langchain-core")}
    install_guard()
    rows = []
    for case_id in selected:
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                result = examples.CASES[case_id]()
                checks = validators.validate(case_id, result)
            rows.append({"id": case_id, "status": "verified", "checks": checks, "result": result})
        except Exception as error:
            rows.append({"id": case_id, "status": "failed", "errorType": type(error).__name__, **({"failedCheck": str(error)} if isinstance(error, AssertionError) else {})})
    print(json.dumps({"schemaVersion": 1, "kind": "adapted-teaching-companions", "originalSourceVerified": False, "pythonVersion": sys.version.split()[0], "dependencies": versions, "hashes": hashes, "boundaries": {"network": "blocked-by-process-audit", "fileWrites": "blocked-by-process-audit", "database": "in-memory-only", "guardScope": "process-local-defense-not-os-sandbox", "modelCalls": 0}, "items": rows}, ensure_ascii=False))
    return 0 if all(row["status"] == "verified" for row in rows) else 1


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
